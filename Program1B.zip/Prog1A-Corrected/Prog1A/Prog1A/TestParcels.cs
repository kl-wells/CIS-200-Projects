﻿// Program 1B
// CIS 200-50
// Fall 2021
// Due: 10/8/2021
// By: 5327405

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Kate Klenda", "4325 Something Ct.", "Burlington", "KY", 41005);
            Address a6 = new Address("Caleb Michael", "40223 Code Way", "Union", "KY", 40227);
            Address a7 = new Address("Abby Kam", "567 Robinhood Dr", "Burlington", "OH", 52931);
            Address a8 = new Address("Karen Kounty", "5372 Dinner Lane", "Destiny", "MA", 23190);

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a5, a6, 2.5M);
            Letter letter3 = new Letter(a7, a8, 1.25M);
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a6, a8, 10, 12, 6, 15);
            GroundPackage gp3 = new GroundPackage(a7, a5, 6, 7, 4, 7);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a5, a8, 10, 12, 14, 20, 6.5M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a6, a7, 17, 18, 8, 45, 8.6M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a8, a6, 10, 20, 8, 25, TwoDayAirPackage.Delivery.Early);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a8, a6, 30, 25, 10, 35, TwoDayAirPackage.Delivery.Saver);

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list 
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);

            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            //Step 1 - Parcels by destination zip in descending order
            var parcelsDestZip =
                from i in parcels
                orderby i.DestinationAddress.Zip descending
                select i;

            WriteLine("Parcels By their Destination Zip Code: ");
            foreach (Parcel i in parcelsDestZip)
            {
                WriteLine($"{i.DestinationAddress.Zip:D5}");
            }
            Pause();

            //Step 2 - Parcels by cost in ascending order
            var parcelsCost =
                from p in parcels
                orderby p.CalcCost()
                select p;

            WriteLine("Parcels By their Cost: ");
            foreach (Parcel p in parcelsCost)
            {
                WriteLine($"{p.CalcCost():C}");
            }
            Pause();

            //Step 3 - Parcels by their ascending type and descending cost
            var parcelsTypeAndCost =
                from parcel in parcels
                orderby parcel.GetType().ToString(), parcel.CalcCost() descending
                select parcel;

            WriteLine("Parcels By their Type and Cost: ");
            foreach (Parcel parcel in parcelsTypeAndCost)
            {
                WriteLine($"{parcel.GetType().ToString()} {parcel.CalcCost():C}");
            }
            Pause();

            //Step 4 - Heavy air packages sorted by weight in descending order
            //first one gets air packages; second sorts them
            var airPackages =
                from a in parcels
                where a is AirPackage
                select (AirPackage)a;

            var heavyAirPackageWeights =
                from h in airPackages
                where h.IsHeavy()
                orderby h.Weight descending
                select h;

            WriteLine("Heavy Air Packages by their Weight: ");
            foreach (AirPackage h in heavyAirPackageWeights)
            {
                WriteLine($"{h.GetType().ToString()} {h.Weight}");
            }
            Pause();
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
